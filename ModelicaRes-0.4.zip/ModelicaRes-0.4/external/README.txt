The "control" folder is a slightly modified version of the python-control
module (http://sourceforge.net/apps/mediawiki/python-control) by Richard
Murray.  The modifications are marked with "ModelicaRes".
